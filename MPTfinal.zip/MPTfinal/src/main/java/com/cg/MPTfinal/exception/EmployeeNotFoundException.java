package com.cg.MPTfinal.exception;

public class EmployeeNotFoundException extends RuntimeException {

	
	String Msg;
	
	
	
	public String getMsg() {
		return Msg;
	}
	public void setMsg(String msg) {
		Msg = msg;
	}
	
	
	
	public EmployeeNotFoundException(String Msg)  {
		super(Msg);
		Msg=this.Msg;
	
	}
}
