package com.cg.MPTfinal.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	 @ExceptionHandler(value= {EmployeeNotFoundException.class})
	    @ResponseStatus(value=HttpStatus.BAD_REQUEST)
	    public EmployeeNotFoundException  exception(EmployeeNotFoundException ef) {
	        
	        String status =  ef.getMsg();
	        System.out.println("My Global exception is working proper!!!!!!");
	        return new EmployeeNotFoundException(status);
	        
	        
	/*@ExceptionHandler(value = { EmployeeNotFoundException.class })
	@ResponseStatus(code = HttpStatus.NOT_FOUND, reason = "Not valid")
	protected void handleConflict() {
		System.out.println("In Global Class");
	}*/
}
}
