package com.cg.MPTfinal.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.MPTfinal.exception.EmployeeNotFoundException;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@Autowired
	MongoTemplate mt;

	@Override
	public List<Employee> readData() {
		// TODO Auto-generated method stub
		return mt.findAll(Employee.class);
	}

	@Override
	public void insertData(Employee e) {
		// TODO Auto-generated method stub
		mt.insert(e);
	}

	@Override
	public Employee updateEmployee(int id, String name) {
		// TODO Auto-generated method stub

		Employee e = mt.findById(id, Employee.class);
		if (e != null) {
			e.setName(name);
			mt.save(e);
		}

		return mt.findById(id, Employee.class);

		/*
		 * Query query=new Query(); query.addCriteria(Criteria.where("id").is(id));
		 * Update update=new Update(); update.set("name", name); mt.updateFirst(query,
		 * update, Employee.class); return mt.findById(id, Employee.class);
		 */
	}

	@Override
	public Employee readoneEmployee(int id) {
		// TODO Auto-generated method stub
		return mt.findById(id, Employee.class);
	}

	@Override
	public void deleteEmployee(int id) {
		Employee e = null;
		try {
			e = mt.findById(id, Employee.class);
			 e.getAge();
		 } catch (Exception e1) {
			 throw new EmployeeNotFoundException("ID doesnt exist!!" +id);
		}

		mt.remove(e);

		/*
		 * Query query=new Query(); query.addCriteria(Criteria.where("id").is(id));
		 * mt.remove(query, Employee.class);
		 */

	}

}
